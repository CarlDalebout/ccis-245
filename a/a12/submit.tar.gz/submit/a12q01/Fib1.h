#ifndef FIB1_H
#define FIB1_H

class Fib1
{
public:
    Fib1()
    {}

    int operator()(const int n);
};

#endif
